import ChekcOutView from "@/views/checkout";

export default function ChekOut() {
  return <ChekcOutView />;
}